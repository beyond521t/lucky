//
//  SecondModel.m
//  DoubleTableView
//
//  Created by 陶柏同 on 2017/4/20.
//  Copyright © 2017年 LaoTao. All rights reserved.
//

#import "SecondModel.h"

@implementation SecondModel

- (NSString *)info {
//    NSInteger num = arc4random() % 3;
//    switch (num) {
//        case 0:
//            return @"=啊上岛咖啡就离开美腿拉到就爱看两地分居卡机封口机爱哦框架黑丝链接拉开距离看刻录机阿鲁卡多风纪扣辣豆腐嘉康利哦i妹子努l.ahdiio刻录机快拉倒就快了";
//            break;
//        case 1:
//            return @"=安吉莉卡急哦开朗大方记录卡就删掉快肥家美足啊记录卡就快了发动机刻录机爱哦起哦";
//            break;
//        default:
//            return @"=情侣简历空间克隆";
//            break;
//    }
    
    return @"=安吉莉卡急哦开朗大方记录卡就删掉快肥家美足啊记录卡就快了发动机刻录机爱哦起哦";

}

@end
