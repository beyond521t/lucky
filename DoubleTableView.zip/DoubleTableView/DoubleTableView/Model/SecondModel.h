//
//  SecondModel.h
//  DoubleTableView
//
//  Created by 陶柏同 on 2017/4/20.
//  Copyright © 2017年 LaoTao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecondModel : NSObject

/** 评论信息 */
@property (nonatomic, copy) NSString *info;

@end
